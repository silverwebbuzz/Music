import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-artist',
  templateUrl: './select-artist.page.html',
  styleUrls: ['./select-artist.page.scss'],
})
export class SelectArtistPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
