import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-music',
  templateUrl: './select-music.page.html',
  styleUrls: ['./select-music.page.scss'],
})
export class SelectMusicPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
