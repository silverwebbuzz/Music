import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-artist',
  templateUrl: './find-artist.page.html',
  styleUrls: ['./find-artist.page.scss'],
})
export class FindArtistPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
